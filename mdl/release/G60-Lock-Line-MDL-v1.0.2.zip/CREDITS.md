# 来源

原项目：[2375120981/G60-Lock-Line](https://github.com/2375120981/G60-Lock-Line)，V1.2.2，提交 cd433d5c67bfd0d25b8b0e82a97baf1d24a5a0ce。
相机投影、几何标记、目标估算和外观参数沿用该项目；MDL 读取与生命周期适配独立实现。
循环设置参考 BFV Hit And Kill Feedback V2.2.0 的 ModOptionsMenu 接口用法；不包含其组件。
本模组为非官方适配，不代表 MDL3 作者或游戏官方提供担保。
